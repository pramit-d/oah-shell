#!/bin/bash

function __oah_provision {
		vagrant provision
}
