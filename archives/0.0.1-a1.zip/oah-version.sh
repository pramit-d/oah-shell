#!/bin/bash


function __oah_version {
	# echo ""
	# __oah_echo_yellow "OAH ${OAH_VERSION}"
	cat $OAH_DIR/var/version
}
