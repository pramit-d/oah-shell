#!/bin/bash
# oah script to show the status of the env on the host
function __oah_status {
vagrant global-status
}
